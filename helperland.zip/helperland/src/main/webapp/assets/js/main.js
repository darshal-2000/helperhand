mybutton = document.getElementById("myBtn1");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
	document.body.scrollTop = 0; 
}

/*book a service*/ 
function myFunction1() {
  document.getElementById("mymenu").classList.toggle("show");
  document.getElementById("triangle").classList.toggle("show");
}
function rotateimg(z,y){
	var x = document.getElementById(y);
	if(x.style.display === "none"){
	document.getElementById(z).style.transform="rotate(90deg)";
	x.style.display = "block";
	}
	else{
	document.getElementById(z).style.transform="rotate(0deg)";
	x.style.display = "none";
	}
}