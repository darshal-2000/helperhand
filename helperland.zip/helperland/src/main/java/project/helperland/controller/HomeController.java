package project.helperland.controller;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;    
import javax.mail.*;    
import javax.mail.internet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import project.helperland.entity.ContactUs;
import project.helperland.entity.ServiceRequest;
import project.helperland.entity.ServiceRequestAddress;
import project.helperland.entity.ServiceRequestExtra;
import project.helperland.entity.ServiceSchedule;
import project.helperland.service.ContactUsService;
import project.helperland.service.ServiceRequestAddressService;
import project.helperland.service.ServiceRequestExtraService;
import project.helperland.service.ServiceRequestService;
import project.helperland.service.UserAddressService;
import project.helperland.entity.User;
import project.helperland.entity.UserAddress;
import project.helperland.service.UserService;
import project.helperland.service.CheckPostalService;

@Controller
public class HomeController {
	
	@Autowired
    private ContactUsService contactus;
	@Autowired
	private UserService user;
	@Autowired
	private CheckPostalService check;
	@Autowired
	private UserAddressService usead;
	
	@Autowired
	private ServiceRequestService theservice;
	@Autowired
	private ServiceRequestAddressService theservicead;
	@Autowired
	private ServiceRequestExtraService theExtra;
	
	static public int flag;
	String msg;

	@RequestMapping(value="/")
	public String test(){
		return "home";
	}
	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("flag",flag);
		model.addAttribute("msg",msg);
		flag=0;
		return "home";
	}
    @RequestMapping("/faq")
	public String faq() throws Exception {
		return "faq";
	}
    @RequestMapping("/prices")
	public String prices() throws Exception {
		return "prices";
	}
    @RequestMapping("/contact")
	public String contact(Model model) throws Exception {
		ContactUs thecontact=new ContactUs();
		model.addAttribute("thecontact",thecontact);
		return "contact";
	}
    
    @PostMapping("/saveContactUs")
    public String saveCustomer(@ModelAttribute("contact") ContactUs theContact,HttpServletResponse response) throws UnsupportedEncodingException {
        contactus.saveContactUs(theContact);
        flag=1;
        msg="Query is reported successfully";
        return "redirect:/home";
    }
    
    @RequestMapping("/be-pro")
	public String be_pro(Model model) throws Exception {
    	User theuser=new User();
		model.addAttribute("user",theuser);
		return "be-pro";
	}
    
    @PostMapping("/SavePro")
    public String SavePro(@ModelAttribute("userRegist") User theuser) {
       try {
    	   user.saveUser(theuser);
    	   flag=1;
    	   msg="Registration Successful you can login once you are verified by admin";
    	   return "redirect:/home";
       }catch(Exception e){
    	   flag=1;
    	   msg="Entered Email is alredy in use";
    	   return "redirect:/home";
       }
    }
    
    @RequestMapping("/about")
	public String about() throws Exception {
		return "about";
	}
    @RequestMapping("/userRegist")
	public String userRegist(Model model) throws Exception {
    	User theuser=new User();
		model.addAttribute("user",theuser);
		return "userRegist";
	}
    
    @PostMapping("/SaveCustomer")
    public String SaveCustomer(@ModelAttribute("userRegist") User theuser) {
        try{
        	user.saveUser(theuser);
        	flag=1;
        	msg="Successuy Registered";
        	return "redirect:/home";
        }catch(Exception e) {
        	flag=1;
        	msg="Email already in use";
        	return "redirect:/home";
        }
       
    }
    
    @PostMapping("/login")
    public String login(Model model,@RequestParam("email") String email,@RequestParam("password") String pass,
    		HttpSession session)throws Exception{
    	List<User> theuser= user.login(email,pass);
    	
    	if(theuser.size()>0) {
    		String u_type=(String)theuser.get(0).getUidtype();
    		String name=(String)theuser.get(0).getFName();
    		String uid=theuser.get(0).getId()+"";
    		String phno=(String)theuser.get(0).getPhoneNumber();
    		session.setAttribute("u_type",u_type);
    		session.setAttribute("name",name);
    		session.setAttribute("uid",uid);
    		session.setAttribute("phno",phno);
    		if(Integer.parseInt(u_type)==1) {
    			return "redirect:/cust-book_a_ser-postal";
    		}
    		model.addAttribute("msg",u_type);
    		return "login_sucessfull" ;
    	}
    	model.addAttribute("msg",email);
    	return "login_sucessfull";
    }
    
    public static void send(String to,String sub,String msg){  
        //Get properties object    
        Properties props = new Properties();    
        props.put("mail.smtp.host", "smtp.gmail.com");    
        props.put("mail.smtp.socketFactory.port", "465");    
        props.put("mail.smtp.socketFactory.class",    
                  "javax.net.ssl.SSLSocketFactory");    
        props.put("mail.smtp.auth", "true");    
        props.put("mail.smtp.port", "465");
        //get Session   
        Session session = Session.getDefaultInstance(props,    
         new javax.mail.Authenticator() {    
         protected PasswordAuthentication getPasswordAuthentication() {    
         return new PasswordAuthentication("mtrainng@gmail.com","darshal@123");  
         }    
        });    
        //compose message    
        try {    
         MimeMessage message = new MimeMessage(session);    
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
         message.setSubject(sub);    
         message.setText(msg);    
         //send message  
         Transport.send(message);    
         System.out.println("message sent successfully");    
        } catch (MessagingException e) {throw new RuntimeException(e);}               
    }  
    
    @PostMapping("/forget")
    public String forget(Model model,@RequestParam("email") String email)throws Exception{
    	if(user.emailvalid(email)>0) {
    		send(email,"Reset password","http://localhost:8080/helperland/forget_pass?email="+email);
    		flag=1;
    		msg="Check Email for change password link";
    		return "redirect:/home";
    	}
    	flag=1;
		msg="Please enter proper email";
		return "redirect:/home";
    }
    
    @GetMapping("/forget_pass")
    public String forget_pass(Model model,@RequestParam("email") String email)throws Exception{
    	model.addAttribute("email", email);
    	return "forget_pass";
    }
    
    @PostMapping("/change_pass")
    public String change_pass(@RequestParam("email") String email,@RequestParam("newpass") String pass) {
    	user.updatepass(email, pass);
    	flag=1;
		msg="Password updated successfully";
    	return "redirect:/home";
    }
    
    @RequestMapping("/cust-book_a_ser-postal")
	public String postal_enter(Model model,HttpServletRequest request,@CookieValue(value="addschedule", defaultValue = "null") String addschedule,
			@CookieValue(value="pincode", defaultValue = "null") String code) throws Exception {
    	if(!addschedule.equals("null")) {
    		return "redirect:/cust-book_a_ser-detail";
    	}
    	if(!code.equals("null")) {
    		return "redirect:/cust-book_a_ser-schedule";
    	}
    	HttpSession session=request.getSession(false); 
    	if(session!=null) {
    		if(Integer.parseInt((String)session.getAttribute("u_type"))==1) {
    			model.addAttribute("flag",flag);
        		model.addAttribute("msg",msg);
        		flag=0;
        		return "cust-book_a_ser-postal";
    		}	
    	}
    	return "redirect:/home";
	}
    
    @RequestMapping("/check_postal_isavailable")
    public String postal_is_available(@RequestParam(value="code",required = false) String code,HttpServletResponse response) {
    	try{
    		if(check.isavailable(code)==0) {
    			flag=1;
    	    	msg="No Service proider available for given postalcode";
    			return "redirect:/cust-book_a_ser-postal";
    		}
    		else {
    			Cookie pincode=new Cookie("pincode",code);
        		response.addCookie(pincode);
    			return "redirect:/cust-book_a_ser-schedule";
    		}
    	}
    	catch(Exception e) {
    		System.out.println(e.getMessage());
    		return "redirect:/cust-book_a_ser-postal";
    	}
    }
    
    @RequestMapping("/cust-book_a_ser-schedule")
	public String Schedule(Model model,HttpServletRequest request,
			@CookieValue(value="pincode", defaultValue = "null") String code) throws Exception {
    	if(code.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	ServiceSchedule schedule=new ServiceSchedule();
    	model.addAttribute("schedule",schedule);
		return "cust-book_a_ser-schedule";
	}
    
    @RequestMapping("/SaveSchedule")
    public String SaveSchedule(@ModelAttribute("cust-book_a_ser-schedule") ServiceSchedule schedule,HttpServletResponse response,
    		HttpServletRequest request,@CookieValue(value="pincode", defaultValue = "null") String code) {
    	if(code.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	Cookie addschedule=new Cookie("addschedule","saved");
		response.addCookie(addschedule);
		HttpSession session=request.getSession(false);
		session.setAttribute("schedule", schedule);
    	System.out.println(schedule.toString());
    	return "redirect:/cust-book_a_ser-detail";
    }
    
    @RequestMapping("/cust-book_a_ser-detail")
	public String book_detail_enter(Model model,HttpServletRequest request,@CookieValue(value="pincode", defaultValue = "null") String code,
			@CookieValue(value="addschedule", defaultValue = "null") String addschedule,
			@CookieValue(value="addDetail", defaultValue = "null") String addDetail) throws Exception {
    	
    	if(!addDetail.equals("null")) {
    		return "redirect:/cust-book_a_ser-pay";
    	}
    	if(addschedule.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	HttpSession session=request.getSession(false);
    	int uid=Integer.parseInt((String)session.getAttribute("uid"));
    	List <UserAddress> thead=usead.getUser(uid,code);
    	model.addAttribute("thead", thead);
		return "cust-book_a_ser-detail";
	}
    
    @RequestMapping("/SaveServiceAddress")
    public String saveServiceAddress(HttpServletRequest request,@RequestParam(value="sname",required = false) String sname,
    	@CookieValue(value="pincode", defaultValue = "null") String code,
    	@RequestParam(value="HNo",required = false) String hno,@RequestParam(value="city",required = false) String city,
    	@RequestParam(value="phno",required = false) String phno,@CookieValue(value="addschedule", defaultValue = "null") String addschedule,
    	HttpServletResponse response) {
    	if(addschedule.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	ServiceRequestAddress thead=new ServiceRequestAddress();
    	HttpSession session=request.getSession(false);
    	thead.setAdline1(sname+" "+hno);
    	thead.setMobile(phno);
    	thead.setPost(code);
    	thead.setCity(city);
    	session.setAttribute("serviceAddress",thead);
    	Cookie addDetail=new Cookie("addDetail","saved");
    	System.out.println(thead.toString());
    	response.addCookie(addDetail);
    	return"redirect:/cust-book_a_ser-pay";
    }
    
    @RequestMapping("/SaveServiceAddressRadio")
    public String saveServiceAddressRadio(HttpServletRequest request,@RequestParam(value="address",required = false) String addressId,
    	@CookieValue(value="addschedule", defaultValue = "null") String addschedule,
    	HttpServletResponse response) {
    	if(addschedule.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	UserAddress address=new UserAddress();
    	address=usead.getUserAddress(Integer.parseInt(addressId));
    	ServiceRequestAddress thead=new ServiceRequestAddress();
    	HttpSession session=request.getSession(false);
    	thead.setAdline1(address.getAdline1());
    	thead.setMobile(address.getMobile());
    	thead.setPost(address.getPost());
    	thead.setCity(address.getCity());
    	session.setAttribute("serviceAddress",thead);
    	Cookie addDetail=new Cookie("addDetail","saved");
    	response.addCookie(addDetail);
    	System.out.println(thead.toString());
    	return"redirect:/cust-book_a_ser-pay";
    }
    
    @RequestMapping("/cust-book_a_ser-pay")
   	public String book_pay(@CookieValue(value="addDetail", defaultValue = "null") String addDetail,
   			@CookieValue(value="addschedule", defaultValue = "null") String addschedule) throws Exception {
    	if(addDetail.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	return "cust-book_a_ser-pay";
   	}
    
    @RequestMapping("completeBooking")
    public String CompletBooking(@CookieValue(value="addDetail", defaultValue = "null") String addDetail,
    		HttpServletRequest request) {
    	if(addDetail.equals("null")) {
    		return "redirect:/cust-book_a_ser-postal";
    	}
    	msg="Booking complete";
    	flag=1;
    	HttpSession session=request.getSession(false);
    	ServiceSchedule schedule=(ServiceSchedule) session.getAttribute("schedule");
    	ServiceRequestAddress thead=(ServiceRequestAddress) session.getAttribute("serviceAddress");
    	ServiceRequest serve=new ServiceRequest();
    	//creating service request
    	serve.setId(Integer.parseInt((String)session.getAttribute("uid")));
    	serve.setStartDate(schedule.getDate());
    	serve.setStartTime(schedule.getTime());
    	serve.setHours(schedule.gettotaltime()+"");
    	serve.setExtraHour((schedule.gettotaltime()-Integer.parseInt(schedule.getDuration()))+"");
    	serve.setCode(thead.getPost());
    	serve.setTotal((schedule.gettotaltime()*20)+"");
    	serve.setSubTotal((schedule.gettotaltime()*20)+"");
    	if(schedule.getHaspet()!=null) {serve.setHasPet(schedule.getHaspet());}
    	if(schedule.getComment()!=null) {serve.setComment(schedule.getComment());}
    	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
        Date date = new Date();
        serve.setCreateDate(formatter.format(date));
        serve.setModifyDate(formatter.format(date));
        theservice.saveService(serve);
        
        //creating service request address
        ServiceRequestAddress thead2=new ServiceRequestAddress();
        thead2.setSRid(serve.getSRid());
        thead2.setAdline1(thead.getAdline1());
        thead2.setCity(thead.getCity());
        thead2.setPost(thead.getPost());
        thead2.setMobile(thead.getMobile());
        theservicead.saveSercvice(thead2);
        
        //creating service request extra
        if(schedule.getWin()!=null) {
			ServiceRequestExtra et1=new ServiceRequestExtra();
			et1.setSRId(serve.getSRid());
			et1.setExtraId(0);
			theExtra.saveExtra(et1);
		}
		if(schedule.getCab()!=null) {
			ServiceRequestExtra et2=new ServiceRequestExtra();
			et2.setSRId(serve.getSRid());
			et2.setExtraId(1);
			theExtra.saveExtra(et2);
		}
		if(schedule.getLd()!=null) {
			ServiceRequestExtra et3=new ServiceRequestExtra();
			et3.setSRId(serve.getSRid());
			et3.setExtraId(2);
			theExtra.saveExtra(et3);
		}
		if(schedule.getFridge()!=null) {
			ServiceRequestExtra et4=new ServiceRequestExtra();
			et4.setSRId(serve.getSRid());
			et4.setExtraId(3);
			theExtra.saveExtra(et4);
		}
		if(schedule.getOven()!=null) {
			ServiceRequestExtra et5=new ServiceRequestExtra();
			et5.setSRId(serve.getSRid());
			et5.setExtraId(4);
			theExtra.saveExtra(et5);
		}
        
        return "redirect:/home";
    }
    
}
