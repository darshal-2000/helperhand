package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="servicerequest")
public class ServiceRequest {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ServiceRequestId")
	private int SRid;
	
	@Column(name="UserId")
	private int id;
	
	@Column(name="ServiceStartDate")
	private String startDate;
	
	@Column(name="ServiceStartTime")
	private String startTime;
	
	@Column(name="ExtraHour")
	private String extraHour="0";
	
	@Column(name="Zipcode")
	private String code;
	
	@Column(name="ServiceHour")
	private String hours;
	
	@Column(name="SubTotal")
	private String subTotal;
	
	@Column(name="TotalCost")
	private String Total;
	
	@Column(name="Comment")
	private String comment="0";
	
	@Column(name="JobStatus")
	private String jobStatus="0";
	
	@Column(name="ServiceProviderId")
	private int SP_Id;
	
	@Column(name="SPAcceptDate")
	private String acceptDate;
	
	@Column(name="HasPets")
	private String hasPet="0";
	
	@Column(name="CreatedDate")
	private String createDate;
	
	@Column(name="ModifiedDate")
	private String modifyDate;

	public int getSRid() {
		return SRid;
	}

	public void setSRid(int sRid) {
		SRid = sRid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getExtraHour() {
		return extraHour;
	}

	public void setExtraHour(String extraHour) {
		this.extraHour = extraHour;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(String subTotal) {
		this.subTotal = subTotal;
	}

	public String getTotal() {
		return Total;
	}

	public void setTotal(String total) {
		Total = total;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public int getSP_Id() {
		return SP_Id;
	}

	public void setSP_Id(int sP_Id) {
		SP_Id = sP_Id;
	}

	public String getAcceptDate() {
		return acceptDate;
	}

	public void setAcceptDate(String acceptDate) {
		this.acceptDate = acceptDate;
	}

	public String getHasPet() {
		return hasPet;
	}

	public void setHasPet(String hasPet) {
		this.hasPet = hasPet;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Override
	public String toString() {
		return "ServiceRequest [SRid=" + SRid + ", id=" + id + ", startDate=" + startDate + ", startTime=" + startTime
				+ ", extraHour=" + extraHour + ", code=" + code + ", hours=" + hours + ", subTotal=" + subTotal
				+ ", Total=" + Total + ", comment=" + comment + ", jobStatus=" + jobStatus + ", SP_Id=" + SP_Id
				+ ", acceptDate=" + acceptDate + ", hasPet=" + hasPet + ", createDate=" + createDate + ", modifyDate="
				+ modifyDate + "]";
	}
	
}
