package project.helperland.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServiceRequestAddress;

@Repository
public class ServiceRequestAddressDAOImpl implements ServiceRequestAddressDAO {
	@Autowired
    private SessionFactory sessionFactory;
	public void saveSercvice(ServiceRequestAddress thead) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(thead);
	}
}
