package project.helperland.dao;

import project.helperland.entity.ContactUs;

public interface ContactUsDAO {
	public void saveContactUs(ContactUs contact);
}
