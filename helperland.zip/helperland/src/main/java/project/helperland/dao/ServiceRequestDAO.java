package project.helperland.dao;

import project.helperland.entity.ServiceRequest;

public interface ServiceRequestDAO {
	public void saveService(ServiceRequest service);
}
