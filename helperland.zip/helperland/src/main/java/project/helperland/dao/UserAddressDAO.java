package project.helperland.dao;

import java.util.List;

import project.helperland.entity.UserAddress;

public interface UserAddressDAO {
	public void saveUser(UserAddress Userad);

    public List <UserAddress> getUser(int theId,String code);
    
    public UserAddress getUserAddress(int theId);
    
}
