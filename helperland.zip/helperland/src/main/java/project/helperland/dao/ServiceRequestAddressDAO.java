package project.helperland.dao;

import project.helperland.entity.ServiceRequestAddress;

public interface ServiceRequestAddressDAO {
	public void saveSercvice(ServiceRequestAddress thead);
}
