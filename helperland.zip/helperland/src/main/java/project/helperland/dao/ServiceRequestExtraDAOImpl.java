package project.helperland.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServiceRequestExtra;

@Repository
public class ServiceRequestExtraDAOImpl implements ServiceRequestExtraDAO {
	@Autowired
    private SessionFactory sessionFactory;

	@Override
	public void saveExtra(ServiceRequestExtra extra) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(extra);
	}
	
	
}
