package project.helperland.dao;

import project.helperland.entity.UserAddress;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import java.util.List;

import javax.persistence.Query;

@Repository
public class UserAddressDAOImpl implements UserAddressDAO {
	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
	public void saveUser(UserAddress Userad) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(Userad);
	}

    @SuppressWarnings("unchecked")
    @Override
    public List <UserAddress> getUser(int theId,String code) {
    	Session session = sessionFactory.getCurrentSession();
        String hql = "FROM UserAddress u WHERE u.id = :id AND u.post =:code";
        Query query = session.createQuery(hql);
        query.setParameter("id",theId);
        query.setParameter("code",code);
        return query.getResultList();
    }
    @SuppressWarnings("unchecked")
    @Override
    public UserAddress getUserAddress(int theId) {
    	Session session = sessionFactory.getCurrentSession();
        String hql = "FROM UserAddress u WHERE u.adid = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id",theId);
		List<UserAddress> l1= query.getResultList();
        return l1.get(0) ;
    }
}
