package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.ServiceRequestDAO;
import project.helperland.entity.ServiceRequest;

@Service
public class ServiceRequestServiceImpl implements ServiceRequestService {
	@Autowired
	private ServiceRequestDAO theservice;
	
	@Override
	@Transactional
	public void saveService(ServiceRequest service) {
		theservice.saveService(service);
	}
}
