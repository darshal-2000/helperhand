package project.helperland.service;

import java.util.List;
import project.helperland.entity.UserAddress;


public interface UserAddressService {
	public void saveUser(UserAddress Userad);

    public List <UserAddress> getUser(int theId,String code);
    
    public UserAddress getUserAddress(int theId);
    
}
