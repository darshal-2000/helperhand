package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.UserAddressDAO;
import project.helperland.entity.UserAddress;

@Service
public class UserAddressServiceImpl implements UserAddressService{
	@Autowired
    private UserAddressDAO useraddressDAO;
	
	@Override
	@Transactional
	public void saveUser(UserAddress Userad) {
		useraddressDAO.saveUser(Userad);
	}
	
	@Override
	@Transactional
    public List <UserAddress> getUser(int theId,String code){
    	return useraddressDAO.getUser(theId,code);
    }
	
	@Override
	@Transactional
	public UserAddress getUserAddress(int theId) {
		return useraddressDAO.getUserAddress(theId);
	}
	
}
