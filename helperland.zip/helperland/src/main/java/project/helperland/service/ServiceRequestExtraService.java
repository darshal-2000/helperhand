package project.helperland.service;

import project.helperland.entity.ServiceRequestExtra;

public interface ServiceRequestExtraService {
	public void saveExtra(ServiceRequestExtra extra);
}
