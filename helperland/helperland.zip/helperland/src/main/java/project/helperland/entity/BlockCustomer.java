package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="blockcustomer")
public class BlockCustomer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="UserId")
	private int userId;
	
	@Column(name="TargetUserId")
	private int TargetUserId;
	
	@Column(name="IsBlock")
	private int IsBlock;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getTargetUserId() {
		return TargetUserId;
	}

	public void setTargetUserId(int targetUserId) {
		TargetUserId = targetUserId;
	}

	public int getIsBlock() {
		return IsBlock;
	}

	public void setIsBlock(int isBlock) {
		IsBlock = isBlock;
	}

	@Override
	public String toString() {
		return "BlockCustomer [id=" + id + ", userId=" + userId + ", TargetUserId=" + TargetUserId + ", IsBlock="
				+ IsBlock + "]";
	}
	
	
}
