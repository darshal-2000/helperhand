package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.BlockCustomerDAO;
import project.helperland.entity.BlockCustomer;

@Service
public class BlockCustomerServiceImpl implements BlockCustomerService{

	@Autowired
	BlockCustomerDAO block;
	
	@Override
	@Transactional
	public void saveBlock(BlockCustomer theUser) {
		block.saveBlock(theUser);
	}

	@Override
	@Transactional
	public int isBlock(int userId, int TargetId) {
		return block.isBlock(userId, TargetId);
	}

	@Override
	@Transactional
	public BlockCustomer CheckData(int userId, int TargetId) {
		return block.CheckData(userId, TargetId);
	}
	
}
