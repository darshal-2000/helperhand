package project.helperland.dao;

import java.util.List;

import project.helperland.entity.AdminServiceRequest;

public interface AdminServiceRequestDAO {
	public List<AdminServiceRequest> requestList();
}
