package project.helperland.dao;

import project.helperland.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;


import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

@Repository
public class UserDAOImpl implements UserDAO{
	@Autowired
    private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
    public List < User > getUser() {
        Session session = sessionFactory.getCurrentSession();
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery < User > cq = cb.createQuery(User.class);
        Root < User > root = cq.from(User.class);
        cq.select(root);
        Query query = session.createQuery(cq);
        return query.getResultList();
    }

    @Override
    public void deleteUser(int id) {
        Session session = sessionFactory.getCurrentSession();
        User book = session.byId(User.class).load(id);
        session.delete(book);
    }

    @Override
    public void saveUser(User theUser) {
        Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(theUser);
    }

    @Override
    public User getUser(int theId) {
        Session currentSession = sessionFactory.getCurrentSession();
        User theUser = currentSession.get(User.class, theId);
        return theUser;
    }
	
    @SuppressWarnings("unchecked")
	@Override
    public List <User> login(String email,String pass) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "FROM User u WHERE u.Email = :email AND u.password = :pass";
        Query query = session.createQuery(hql);
        query.setParameter("email", email);
        query.setParameter("pass", pass);
        return query.getResultList();
    }
    
    @Override
    public int emailvalid(String email) {
    	Session session = sessionFactory.getCurrentSession();
        String hql = "FROM User u WHERE u.Email = :email";
        Query query = session.createQuery(hql);
        query.setParameter("email", email);
        @SuppressWarnings("unchecked")
		List <User> u=query.getResultList();
        if(u.size()>0) {
        	return 1;
        }
        return 0;
    }
    
    @Override
    public void updatepass(String email,String pass) {
    	Session session = sessionFactory.getCurrentSession();
        String hql = "Update User  set password = :pass WHERE Email = :email";
        Query query = session.createQuery(hql);
        query.setParameter("pass", pass);
        query.setParameter("email", email);
        query.executeUpdate();
    }

	@Override
	public int checkPassword(int id, String pass) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM User u WHERE u.password = :pass AND id =:id";
        Query query = session.createQuery(hql);
        query.setParameter("pass", pass);
        query.setParameter("id",id);
		if(query.getResultList().size()>0) {
			return 1;
		}
		return 0;
	}

	@Override
	public User filteruser(Integer id, String role, String email, String number, String code, String from, String to) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM User u WHERE u.id=:id AND u.uidtype=:role AND u.Email=:email AND u.PhoneNumber=:number AND u.code=:code AND"
        		+ " STR_TO_DATE(u.CreateDate, '%d-%m-%Y') >=STR_TO_DATE(:from,'%m/%d/%Y') AND STR_TO_DATE(u.CreateDate, '%d-%m-%Y')<=STR_TO_DATE(:to,'%m/%d/%Y')";
        Query query = session.createQuery(hql);
        query.setParameter("id",id);
        query.setParameter("role",role);
        query.setParameter("email",email);
        query.setParameter("number",number);
        query.setParameter("code",code);
        query.setParameter("from",from);
        query.setParameter("to",to);
        @SuppressWarnings("unchecked")
		List<User> l1=query.getResultList();
        if(l1.size()==0) {
        	return null;
        }
        return (User) l1.get(0);
	}
    
}
