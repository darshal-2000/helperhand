package project.helperland.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="rating")
public class SP_Rating {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RatingId")
	private int id;
	
	@Column(name="ServiceRequestId")
	private int SR_id;
	
	@Column(name="RatingFrom")
	private int from;
	
	@Column(name="RatingTo")
	private int to;
	
	@Column(name="Rating")
	private float rating;
	
	@Column(name="comment")
	private String comment;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="ServiceRequestId",insertable = false, updatable = false)
	private ServiceRequest request;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="RatingFrom",insertable = false, updatable = false)
	private User user;
	

	
	public int getSR_id() {
		return SR_id;
	}

	public void setSR_id(int sR_id) {
		SR_id = sR_id;
	}

	public int getFrom() {
		return from;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	public int getTo() {
		return to;
	}

	public void setTo(int to) {
		this.to = to;
	}

	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	
	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public ServiceRequest getRequest() {
		return request;
	}

	public void setRequest(ServiceRequest request) {
		this.request = request;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "SP_Rating [SR_id=" + SR_id + ", from=" + from + ", to=" + to + ", rating=" + rating + ", comment="
				+ comment + ", request=" + request + ", user=" + user + "]";
	}

	

	
}
