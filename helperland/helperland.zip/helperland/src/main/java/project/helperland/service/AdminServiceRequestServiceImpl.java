package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.entity.AdminServiceRequest;

import project.helperland.dao.AdminServiceRequestDAO;

@Service
public class AdminServiceRequestServiceImpl implements AdminServiceRequestService{
	@Autowired
	AdminServiceRequestDAO request;
	
	@Override
	@Transactional
	public List<AdminServiceRequest> requestList() {
		return request.requestList();
	}

}
