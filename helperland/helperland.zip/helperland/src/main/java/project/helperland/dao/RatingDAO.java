package project.helperland.dao;

import project.helperland.entity.Rating;

public interface RatingDAO {
	public void saveRating(Rating rating);
	public double getAvgRating(int id);
	public int isRated(int id);
}
