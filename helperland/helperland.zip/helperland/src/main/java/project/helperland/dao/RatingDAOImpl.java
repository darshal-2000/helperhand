package project.helperland.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.Rating;

@Repository
public class RatingDAOImpl implements RatingDAO {
	@Autowired
    private SessionFactory sessionFactory;

	@Override
	public void saveRating(Rating rating) {
		 Session currentSession = sessionFactory.getCurrentSession();
	     currentSession.saveOrUpdate(rating);
	}

	@Override
	public double getAvgRating(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "Select avg(u.rating) FROM Rating u WHERE u.to = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        if(query.getResultList().get(0)==null) {
        	return 0;
        }
		return (double)query.getResultList().get(0);
	}

	@Override
	public int isRated(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM Rating u WHERE u.SR_id = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        if(query.getResultList().size()==0) {
        	return 0;
        }
		return 1;
	}
}
