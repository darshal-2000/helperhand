package project.helperland.dao;

import java.util.List;

import project.helperland.entity.SP_Rating;

public interface SP_RatingDAO {
	public List<SP_Rating> getRatings(int id);  
}
