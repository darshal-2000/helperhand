package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.UserDAO;
import project.helperland.entity.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
    private UserDAO userDAO;
	
	@Override
	@Transactional
	public List < User > getUser(){
		return userDAO.getUser();
	}
	@Override
	@Transactional
    public void saveUser(User theUser) {
		userDAO.saveUser(theUser);
	}
	@Override
	@Transactional
    public User getUser(int theId) {
		return userDAO.getUser(theId);
	}
	@Override
	@Transactional
    public void deleteUser(int theId) {
		userDAO.deleteUser(theId);
	}
	
	@Override
	@Transactional
	public List < User > login(String email,String pass){
		return userDAO.login(email,pass);
	}
	
	@Override
	@Transactional
	public int emailvalid(String email) {
		return userDAO.emailvalid(email);
	}
	
	
	@Override
	@Transactional
	public void updatepass(String email,String pass){
		 userDAO.updatepass(email,pass);
	}
	
}
