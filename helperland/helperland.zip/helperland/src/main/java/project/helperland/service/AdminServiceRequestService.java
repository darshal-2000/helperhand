package project.helperland.service;

import java.util.List;

import project.helperland.entity.AdminServiceRequest;

public interface AdminServiceRequestService {
	public List<AdminServiceRequest> requestList();
}
