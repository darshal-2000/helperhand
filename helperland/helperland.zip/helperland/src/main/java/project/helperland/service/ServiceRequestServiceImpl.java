package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.ServiceRequestDAO;
import project.helperland.entity.ServiceRequest;

@Service
public class ServiceRequestServiceImpl implements ServiceRequestService {
	@Autowired
	private ServiceRequestDAO theservice;
	
	@Override
	@Transactional
	public void saveService(ServiceRequest service) {
		theservice.saveService(service);
	}

	@Override
	@Transactional
	public ServiceRequest getService(int id) {
		return theservice.getService(id);
	}

	@Override
	@Transactional
	public List<Integer> getUsersOfSP(int id) {
		return theservice.getUsersOfSP(id);
	}

	@Override
	@Transactional
	public ServiceRequest filterService(int srid, int id, int spid, String Status, String code,
			String from, String to) {
		return theservice.filterService(srid, id, spid, Status, code, from, to);
	}
}
