package project.helperland.service;

import java.util.List;

import project.helperland.entity.User;

public interface UserService {
	public List < User > getUser();

    public void saveUser(User theUser);

    public User getUser(int theId);

    public void deleteUser(int theId);
    
    public List <User> login(String email,String pass);
    
    public int emailvalid(String email);
    
    public void updatepass(String email,String pass);
    
    public int checkPassword(int id,String pass);
    
    public User filteruser(Integer id,String role,String email,String number,String code, String from, String to);
}
