package project.helperland.service;

public interface CheckPostalService {
	public int isavailable(String code);
}
