package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.RatingDAO;
import project.helperland.entity.Rating;

@Service
public class RatingServicesImpl implements RatingServices{
	
	@Autowired
	private RatingDAO rate;
	
	@Override
	@Transactional
	public void saveRating(Rating rating) {
		rate.saveRating(rating);
		
	}

	@Override
	@Transactional
	public double getAvgRating(int id) {
		return rate.getAvgRating(id);
	}

	@Override
	@Transactional
	public int isRated(int id) {
		return rate.isRated(id);
	}

}
