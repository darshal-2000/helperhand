package project.helperland.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="servicerequest") 
public class CustomerDashboard {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ServiceRequestId")
	private int SRid;
	
	@Column(name="UserId")
	private String id;
	
	@Column(name="ServiceStartDate")
	private String startDate;
	
	@Column(name="ServiceStartTime")
	private String startTime;
	
	@Column(name="ServiceHour")
	private String hours;
	
	@Column(name="TotalCost")
	private String Total;
	
	@Column(name="Comment")
	private String comment="0";
	
	@Column(name="ServiceProviderId")
	private int SP_Id;
	
	@Column(name="HasPets")
	private String hasPet="0";
	
	@Column(name="JobStatus")
	private String jobStatus="0";
	
	@Column(name="ModifiedDate")
	private String modifyDate;
	
	@OneToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="ServiceProviderId",insertable = false, updatable = false)
	private User user;
	

	public int getSRid() {
		return SRid;
	}

	public void setSRid(int sRid) {
		SRid = sRid;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getHours() {
		return hours;
	}

	public void setHours(String hours) {
		this.hours = hours;
	}

	public String getTotal() {
		return Total;
	}

	public void setTotal(String total) {
		Total = total;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getSP_Id() {
		return SP_Id;
	}

	public void setSP_Id(int sP_Id) {
		SP_Id = sP_Id;
	}

	public String getHasPet() {
		return hasPet;
	}

	public void setHasPet(String hasPet) {
		this.hasPet = hasPet;
	}

	
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	
	

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Override
	public String toString() {
		return "CustomerDashboard [SRid=" + SRid + ", id=" + id + ", startDate=" + startDate + ", startTime="
				+ startTime + ", hours=" + hours + ", Total=" + Total + ", comment=" + comment + ", SP_Id=" + SP_Id
				+ ", hasPet=" + hasPet + ", jobStatus=" + jobStatus + ", modifyDate=" + modifyDate + ", user=" + user
				+ "]";
	}

	
	
}
