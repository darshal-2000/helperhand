package project.helperland.service;

import java.util.List;

import project.helperland.entity.ServicedetailForSP;

public interface ServicedetailForSPService {
	public List<ServicedetailForSP> getServicesForSP(String post);
	public List<ServicedetailForSP> getUpComingServicesForSP(int id);
	public List<ServicedetailForSP> getServicesHistoryForSP(int id);
}
