package project.helperland.dao;

import java.util.List;

import project.helperland.entity.ServiceRequestExtra;

public interface ServiceRequestExtraDAO {
	public void saveExtra(ServiceRequestExtra extra);
	public List<ServiceRequestExtra> getbySRid(int id);
}
