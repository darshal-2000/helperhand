package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.CheckPostal;

@Service
public class CheckPostalServiceImpl implements CheckPostalService  {
	@Autowired
    private CheckPostal check;
	
	@Override
	@Transactional
	public int isavailable(String code) {
		return check.isavailable(code);
	}
}
