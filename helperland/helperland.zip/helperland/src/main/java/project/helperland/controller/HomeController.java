package project.helperland.controller;

import java.util.List;
import java.util.Properties;    
import javax.mail.*;    
import javax.mail.internet.*; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import project.helperland.entity.ContactUs;
import project.helperland.service.ContactUsService;
import project.helperland.entity.User;
import project.helperland.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
    private ContactUsService contactus;
	@Autowired
	private UserService user;
	
	static public int flag;
	String msg;

	@RequestMapping(value="/")
	public String test(){
		return "home";
	}
	@RequestMapping("/home")
	public String home(Model model) throws Exception {
		model.addAttribute("flag",flag);
		model.addAttribute("msg",msg);
		return "home";
	}
    @RequestMapping("/faq")
	public String faq() throws Exception {
		return "faq";
	}
    @RequestMapping("/prices")
	public String prices() throws Exception {
		return "prices";
	}
    @RequestMapping("/contact")
	public String contact(Model model) throws Exception {
		ContactUs thecontact=new ContactUs();
		model.addAttribute("thecontact",thecontact);
		return "contact";
	}
    
    @PostMapping("/saveContactUs")
    public String saveCustomer(@ModelAttribute("contact") ContactUs theContact) {
        contactus.saveContactUs(theContact);
        flag=1;
        msg="Query is reported successfully";
        return "redirect:/home";
    }
    
    @RequestMapping("/be-pro")
	public String be_pro(Model model) throws Exception {
    	User theuser=new User();
		model.addAttribute("user",theuser);
		return "be-pro";
	}
    
    @PostMapping("/SavePro")
    public String SavePro(@ModelAttribute("userRegist") User theuser) {
       try {
    	   user.saveUser(theuser);
    	   flag=1;
    	   msg="Registration Successful you can login once you are verified by admin";
    	   return "redirect:/home";
       }catch(Exception e){
    	   flag=1;
    	   msg="Entered Email is alredy in use";
    	   return "redirect:/home";
       }
    }
    
    @RequestMapping("/about")
	public String about() throws Exception {
		return "about";
	}
    @RequestMapping("/userRegist")
	public String userRegist(Model model) throws Exception {
    	User theuser=new User();
		model.addAttribute("user",theuser);
		return "userRegist";
	}
    
    @PostMapping("/SaveCustomer")
    public String SaveCustomer(@ModelAttribute("userRegist") User theuser) {
        try{
        	user.saveUser(theuser);
        	flag=1;
        	msg="Successuy Registered";
        	return "redirect:/home";
        }catch(Exception e) {
        	flag=1;
        	msg="Email already in use";
        	return "redirect:/home";
        }
       
    }
    
    @PostMapping("/login")
    public String login(Model model,@RequestParam("email") String email,@RequestParam("password") String pass)throws Exception{
    	List<User> theuser= user.login(email,pass);
    	
    	if(theuser.size()>0) {
    		model.addAttribute("msg",theuser.get(0).getUidtype());
    		return "login_sucessfull" ;
    	}
    	model.addAttribute("msg",email);
    	return "login_sucessfull";
    }
    
    public static void send(String to,String sub,String msg){  
        //Get properties object    
        Properties props = new Properties();    
        props.put("mail.smtp.host", "smtp.gmail.com");    
        props.put("mail.smtp.socketFactory.port", "465");    
        props.put("mail.smtp.socketFactory.class",    
                  "javax.net.ssl.SSLSocketFactory");    
        props.put("mail.smtp.auth", "true");    
        props.put("mail.smtp.port", "465");
        //get Session   
        Session session = Session.getDefaultInstance(props,    
         new javax.mail.Authenticator() {    
         protected PasswordAuthentication getPasswordAuthentication() {    
         return new PasswordAuthentication("mtrainng@gmail.com","darshal@123");  
         }    
        });    
        //compose message    
        try {    
         MimeMessage message = new MimeMessage(session);    
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
         message.setSubject(sub);    
         message.setText(msg);    
         //send message  
         Transport.send(message);    
         System.out.println("message sent successfully");    
        } catch (MessagingException e) {throw new RuntimeException(e);}               
    }  
    
    @PostMapping("/forget")
    public String forget(Model model,@RequestParam("email") String email)throws Exception{
    	if(user.emailvalid(email)>0) {
    		send(email,"Reset password","http://localhost:8080/helperland/forget_pass?email="+email);
    		flag=1;
    		msg="Check Email for change password link";
    		return "redirect:/home";
    	}
    	flag=1;
		msg="Please enter proper email";
		return "redirect:/home";
    }
    
    @GetMapping("/forget_pass")
    public String forget_pass(Model model,@RequestParam("email") String email)throws Exception{
    	model.addAttribute("email", email);
    	return "forget_pass";
    }
    
    @PostMapping("/change_pass")
    public String change_pass(@RequestParam("email") String email,@RequestParam("newpass") String pass) {
    	user.updatepass(email, pass);
    	flag=1;
		msg="Password updated successfully";
    	return "redirect:/home";
    }
    
   /* @RequestMapping("/cust-book_a_ser-postal")
	public String postal_enter() throws Exception {
		
		return "cust-book_a_ser-postal";
	}*/
    @RequestMapping("/cust-book_a_ser-schedule")
	public String Schedule() throws Exception {
	
		return "cust-book_a_ser-schedule";
	}
    @RequestMapping("/cust-book_a_ser-detail")
	public String book_detail_enter() throws Exception {
		return "cust-book_a_ser-detail";
	}
    
    @RequestMapping("/cust-book_a_ser-pay")
   	public String book_pay() throws Exception {
   		return "cust-book_a_ser-pay";
   	}
}
