package project.helperland.entity;

import com.fasterxml.jackson.annotation.JsonView;

public class ReshedulePopUp {
	@JsonView(Views.Public.class)
	String date;
	
	@JsonView(Views.Public.class)
	String time;
	
	@JsonView(Views.Public.class)
	String street;
	
	@JsonView(Views.Public.class)
	String houseNo;
	
	@JsonView(Views.Public.class)
	String city;
	
	@JsonView(Views.Public.class)
	String mobile;
	
	@JsonView(Views.Public.class)
	String code;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	
}
