package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.CustomerDashboardDAO;
import project.helperland.entity.CustomerDashboard;

@Service
public class CustomerDashboardServiceImpl implements CustomerDashboardService {
	@Autowired
	CustomerDashboardDAO detail;
	
	@Override
	@Transactional
	public List<CustomerDashboard> getDetail(String id){
		return detail.getDetail(id);
	}

	@Override
	@Transactional
	public CustomerDashboard getservicedetail(int id) {
		return detail.getservicedetail(id);
	}

	@Override
	@Transactional
	public int update(int id, String on, String at) {
		return detail.update(id,on,at);
	}

	@Override
	@Transactional
	public int checkSPdateANDtime(int id, String on, String at) {
		return detail.checkSPdateANDtime(id, on, at) ;
	}

	@Override
	@Transactional
	public void CancelService(int id, String reason) {
		detail.CancelService(id, reason);
		
	}
	
	@Override
	@Transactional
	public List<CustomerDashboard> getServiceHistory(String id){
		return detail.getServiceHistory(id);
	}
}
