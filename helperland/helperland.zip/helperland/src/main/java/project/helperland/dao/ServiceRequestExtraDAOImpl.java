package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServiceRequestExtra;

@Repository
public class ServiceRequestExtraDAOImpl implements ServiceRequestExtraDAO {
	@Autowired
    private SessionFactory sessionFactory;

	@Override
	public void saveExtra(ServiceRequestExtra extra) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(extra);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ServiceRequestExtra> getbySRid(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM ServiceRequestExtra u WHERE u.SRId = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        return query.getResultList();
	}
}
