package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.ServiceRequestExtraDAO;
import project.helperland.entity.ServiceRequestExtra;

@Service
public class ServiceRequestExtraServiceImpl implements ServiceRequestExtraService {
	
	@Autowired
    private ServiceRequestExtraDAO theExtra;

	@Override
	@Transactional
	public void saveExtra(ServiceRequestExtra extra) {
		theExtra.saveExtra(extra);
		
	}
	
	@Override
	@Transactional
	public List<ServiceRequestExtra> getbySRid(int id) {
		return theExtra.getbySRid(id);
	}
	
}
