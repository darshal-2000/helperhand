package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="User_id")
	private int id;
	
	@Column(name="First_Name")
	private String FName;
	
	@Column(name="Last_Name")
	private String LName;
	
	@Column(name="Email",unique=true)
	private String Email;
	
	@Column(name="password")
	private String password;
	
	@Column(name="Mobile")
	private String PhoneNumber;
	
	@Column(name="UserTypeId")
	private String uidtype="0";
	
	@Column(name="IsRegisteredUser")
	private String isRegistered="1";
	
	@Column(name="WorkWithPets")
	private String WorkPet="0";
	
	@Column(name="CreatedDate")
	private String CreateDate;
	
	@Column(name="ModifiedDate")
	private String ModifyDate;
	
	@Column(name="ModifiedBy")
	private String ModifyBy="0";
	
	@Column(name="IsApproved")
	private String isApproved="1";
	
	@Column(name="IsActive")
	private String isActive="1";
	
	@Column(name="IsDeleted")
	private String isDeleted="0";
	
	@Column(name="IsOnline")
	private String isonline="0";

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFName() {
		return FName;
	}

	public void setFName(String fName) {
		FName = fName;
	}

	public String getLName() {
		return LName;
	}

	public void setLName(String lName) {
		LName = lName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getPassword() {
		return password;
	}

	

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	
	public String getUidtype() {
		return uidtype;
	}

	public void setUidtype(String uidtype) {
		this.uidtype = uidtype;
	}

	public String getIsRegistered() {
		return isRegistered;
	}

	public void setIsRegistered(String isRegistered) {
		this.isRegistered = isRegistered;
	}

	public String getWorkPet() {
		return WorkPet;
	}

	public void setWorkPet(String workPet) {
		WorkPet = workPet;
	}

	public String getCreateDate() {
		return CreateDate;
	}

	public void setCreateDate(String createDate) {
		CreateDate = createDate;
	}

	public String getModifyDate() {
		return ModifyDate;
	}

	public void setModifyDate(String modifyDate) {
		ModifyDate = modifyDate;
	}

	public String getModifyBy() {
		return ModifyBy;
	}

	public void setModifyBy(String modifyBy) {
		ModifyBy = modifyBy;
	}

	public String getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(String isApproved) {
		this.isApproved = isApproved;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getIsonline() {
		return isonline;
	}

	public void setIsonline(String isonline) {
		this.isonline = isonline;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", FName=" + FName + ", LName=" + LName + ", Email=" + Email + ", password="
				+ password + ", PhoneNumber=" + PhoneNumber + ", uidtype=" + uidtype + ", isRegistered=" + isRegistered
				+ ", WorkPet=" + WorkPet + ", CreateDate=" + CreateDate + ", ModifyDate=" + ModifyDate + ", ModifyBy="
				+ ModifyBy + ", isApproved=" + isApproved + ", isActive=" + isActive + ", isDeleted=" + isDeleted
				+ ", isonline=" + isonline + ", getId()=" + getId() + ", getFName()=" + getFName() + ", getLName()="
				+ getLName() + ", getEmail()=" + getEmail() + ", getPassword()=" + getPassword() + ", getPhoneNumber()="
				+ getPhoneNumber() + ", getUidtype()=" + getUidtype() + ", getIsRegistered()=" + getIsRegistered()
				+ ", getWorkPet()=" + getWorkPet() + ", getCreateDate()=" + getCreateDate() + ", getModifyDate()="
				+ getModifyDate() + ", getModifyBy()=" + getModifyBy() + ", getIsApproved()=" + getIsApproved()
				+ ", getIsActive()=" + getIsActive() + ", getIsDeleted()=" + getIsDeleted() + ", getIsonline()="
				+ getIsonline() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	
	
	
	
}
