package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="servicerequestextra")
public class ServiceRequestExtra {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ServiceRequestExtraId")
	private int id;
	
	@Column(name="ServiceRequestId")
	private int SRId;
	
	@Column(name="ServiceExtraId")
	private int extraId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSRId() {
		return SRId;
	}

	public void setSRId(int sRId) {
		SRId = sRId;
	}

	public int getExtraId() {
		return extraId;
	}

	public void setExtraId(int extraId) {
		this.extraId = extraId;
	}

	@Override
	public String toString() {
		return "ServiceRequestExtra [id=" + id + ", SRId=" + SRId + ", extraId=" + extraId + "]";
	}
	
}
