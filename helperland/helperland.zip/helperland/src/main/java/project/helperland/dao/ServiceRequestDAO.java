package project.helperland.dao;

import java.util.List;

import project.helperland.entity.ServiceRequest;

public interface ServiceRequestDAO {
	public void saveService(ServiceRequest service);
	public ServiceRequest getService(int id);
	public List<Integer> getUsersOfSP(int id);
}
