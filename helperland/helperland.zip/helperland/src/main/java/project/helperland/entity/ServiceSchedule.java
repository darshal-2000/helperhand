package project.helperland.entity;

public class ServiceSchedule {
	String date;
	String time;
	String duration="0";
	String win="0";
	String ld="0";
	String cab="0";
	String oven="0";
	String fridge="0";
	String comment;
	String haspet;
	String extra="0";
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getWin() {
		return win;
	}
	public void setWin(String win) {
		this.win = win;
	}
	public String getLd() {
		return ld;
	}
	public void setLd(String ld) {
		this.ld = ld;
	}
	public String getCab() {
		return cab;
	}
	public void setCab(String cab) {
		this.cab = cab;
	}
	public String getOven() {
		return oven;
	}
	public void setOven(String oven) {
		this.oven = oven;
	}
	public String getFridge() {
		return fridge;
	}
	public void setFridge(String fridge) {
		this.fridge = fridge;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getHaspet() {
		return haspet;
	}
	public void setHaspet(String haspet) {
		this.haspet = haspet;
	}
	
	public String getExtra() {
		return extra;
	}
	public void setExtra(String extra) {
		this.extra = extra;
	}
	
	public float gettotaltime() {
		float time=Integer.parseInt(duration);
		if(getWin()!=null) {
			time+=0.5;
		}
		if(getCab()!=null) {
			time+=0.5;
		}
		if(getLd()!=null) {
			time+=0.5;
		}
		if(getFridge()!=null) {
			time+=0.5;
		}
		if(getOven()!=null) {
			time+=0.5;
		}
		return time;
	}
	
	@Override
	public String toString() {
		return "ServiceSchedule [date=" + date + ", time=" + time + ", duration=" + duration + ", win=" + win + ", ld="
				+ ld + ", cab=" + cab + ", oven=" + oven + ", fridge=" + fridge + ", comment=" + comment + ", haspet="
				+ haspet + ", extra=" + extra + "]";
	}
	
}
