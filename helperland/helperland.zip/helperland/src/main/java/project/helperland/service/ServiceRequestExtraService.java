package project.helperland.service;


import java.util.List;

import project.helperland.entity.ServiceRequestExtra;

public interface ServiceRequestExtraService {
	public void saveExtra(ServiceRequestExtra extra);
	public List<ServiceRequestExtra> getbySRid(int id);
}
