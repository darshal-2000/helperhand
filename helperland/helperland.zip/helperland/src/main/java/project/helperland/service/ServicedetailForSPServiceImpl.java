package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.ServicedetailForSPDAO;
import project.helperland.entity.ServicedetailForSP;

@Service
public class ServicedetailForSPServiceImpl implements ServicedetailForSPService{
	
	@Autowired
	ServicedetailForSPDAO request;
	
	@Override
	@Transactional
	public List<ServicedetailForSP> getServicesForSP(String post) {
		return request.getServicesForSP(post);
	}

	@Override
	@Transactional
	public List<ServicedetailForSP> getUpComingServicesForSP(int id) {
		return request.getUpComingServicesForSP(id);
	}

	@Override
	@Transactional
	public List<ServicedetailForSP> getServicesHistoryForSP(int id) {
		return request.getServicesHistoryForSP(id);
	}
	
}
