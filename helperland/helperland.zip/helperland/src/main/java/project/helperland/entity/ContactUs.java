package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ContactUs")
public class ContactUs {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ContactUsId")
	private int id;
	
	@Column(name="Name")
	private String Name;
	
	@Column(name="Email")
	private String Email;
	

	@Column(name="SubjectType")
	private String SubjectType;
	
	@Column(name="PhoneNumber")
	private String PhoneNumber;
	
	@Column(name="Message")
	private String message;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	public String getSubjectType() {
		return SubjectType;
	}

	public void setSubjectType(String subjectType) {
		SubjectType = subjectType;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ContactUs [id=" + id + ", Name=" + Name + ", email=" + Email + ", SubjectType=" + SubjectType
				+ ", PhoneNumber=" + PhoneNumber + ", message=" + message + "]";
	}

	
}
