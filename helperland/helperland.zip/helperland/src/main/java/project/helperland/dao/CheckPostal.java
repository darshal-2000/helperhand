package project.helperland.dao;

public interface CheckPostal {
	public int isavailable(String code);
}
