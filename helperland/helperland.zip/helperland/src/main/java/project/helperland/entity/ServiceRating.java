package project.helperland.entity;

import com.fasterxml.jackson.annotation.JsonView;

public class ServiceRating {
	@JsonView(Views.Public.class)
	int SP_id;
	@JsonView(Views.Public.class)
	String name;
	@JsonView(Views.Public.class)
	Double rating;
	
	public int getSP_id() {
		return SP_id;
	}
	public void setSP_id(int sP_id) {
		SP_id = sP_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "ServiceRating [SP_id=" + SP_id + ", name=" + name + ", rating=" + rating + "]";
	}
	
	
}
