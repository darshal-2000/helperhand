package project.helperland.service;

import project.helperland.entity.Rating;

public interface RatingServices {
	public void saveRating(Rating rating);
	public double getAvgRating(int id);
	public int isRated(int id);
}
