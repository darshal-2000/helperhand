package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.User;

@Repository
public class CheckPostalImpl implements CheckPostal{
	@Autowired
	private SessionFactory sessionFactory;
	
	public int isavailable(String code){
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM User u WHERE u.code = :code AND u.uidtype = :type AND isApproved = :approve";
        Query query = session.createQuery(hql);
        query.setParameter("code", code);
        query.setParameter("type","0");
        query.setParameter("approve","1");
        @SuppressWarnings("unchecked")
		List <User> u=query.getResultList();
        if(u.size()>0) {
        	return 1;
        }
        return 0;
	}
}
