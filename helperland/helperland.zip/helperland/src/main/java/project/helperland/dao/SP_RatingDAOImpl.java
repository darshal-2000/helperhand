package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.SP_Rating;

@Repository
public class SP_RatingDAOImpl implements SP_RatingDAO{
	
	@Autowired
    private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<SP_Rating> getRatings(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM SP_Rating u WHERE u.to = :to";
        Query query = session.createQuery(hql);
        query.setParameter("to",id);
		return query.getResultList();
	}

}
