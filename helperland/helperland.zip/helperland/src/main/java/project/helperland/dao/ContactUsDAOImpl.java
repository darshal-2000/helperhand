package project.helperland.dao;

import project.helperland.entity.ContactUs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ContactUsDAOImpl implements ContactUsDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void saveContactUs(ContactUs contact) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(contact);
	}
}
