package project.helperland.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.CustomerDashboard;

@Repository
public class CustomerDashboardDAOImpl implements CustomerDashboardDAO{
	@Autowired
    private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerDashboard> getDetail(String id) {
		 Session session = sessionFactory.getCurrentSession();
	        String hql = "FROM CustomerDashboard u WHERE u.id = :id AND jobStatus = 0";
	        Query query = session.createQuery(hql);
	        query.setParameter("id", id);
	        return query.getResultList();
	}

	@Override
	public CustomerDashboard getservicedetail(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM CustomerDashboard u WHERE u.SRid = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        return (CustomerDashboard)query.getResultList().get(0);
	}

	@Override
	public int update(int id, String on, String at) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDateTime now = LocalDateTime.now();
		String date=dtf.format(now);
		Session session = sessionFactory.getCurrentSession();
		String hql = "UPDATE CustomerDashboard  set startDate =:on, startTime =:at ,modifyDate =:date where SRid =:id";
		Query query = session.createQuery(hql);
        query.setParameter("on", on);
        query.setParameter("at", at);
        query.setParameter("id", id);
        query.setParameter("date", date);
        query.executeUpdate();
        return 1;
	}

	@Override
	public int checkSPdateANDtime(int id,String on,String at) {
		Session session = sessionFactory.getCurrentSession();
		String hql = "FROM CustomerDashboard u WHERE u.SP_Id = :id AND u.startDate =:on AND u.startTime =:at1";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        query.setParameter("on", on);
        query.setParameter("at1", at);
        return query.getResultList().size();
	}

	@Override
	public void CancelService(int id,String reason) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDateTime now = LocalDateTime.now();
		String date=dtf.format(now);
		reason="Cancel due to"+reason;
		Session session = sessionFactory.getCurrentSession();
		String hql = "UPDATE CustomerDashboard set jobStatus = -1,modifyDate =:date,comment =:reason where SRid =:id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        query.setParameter("date", date);
        query.setParameter("reason",reason);
        query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CustomerDashboard> getServiceHistory(String id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM CustomerDashboard u WHERE u.id = :id AND jobStatus <> 0";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        return query.getResultList();
		
	}
}
