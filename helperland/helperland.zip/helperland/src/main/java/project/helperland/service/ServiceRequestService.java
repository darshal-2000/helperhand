package project.helperland.service;

import java.util.List;

import project.helperland.entity.ServiceRequest;

public interface ServiceRequestService {
	public void saveService(ServiceRequest service);
	public ServiceRequest getService(int id);
	public List<Integer> getUsersOfSP(int id);
}
