package project.helperland.service;

import project.helperland.entity.ServiceRequest;

public interface ServiceRequestService {
	public void saveService(ServiceRequest service);
}
