package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="servicerequestaddress")
public class ServiceRequestAddress {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Id")
	private int id;
	
	@Column(name="ServiceRequestId")
	private int SRid;
	
	@Column(name="AddressLine1")
	private String adline1;
	
	@Column(name="AddressLine2")
	private String adline2;
	
	@Column(name="City")
	private String city;
	
	@Column(name="State")
	private String state;
	
	@Column(name="postalcode")
	private String post;
	
	@Column(name="Mobile")
	private String mobile;
	
	@Column(name="Email")
	private String email;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSRid() {
		return SRid;
	}

	public void setSRid(int sRid) {
		SRid = sRid;
	}

	public String getAdline1() {
		return adline1;
	}

	public void setAdline1(String adline1) {
		this.adline1 = adline1;
	}

	public String getAdline2() {
		return adline2;
	}

	public void setAdline2(String adline2) {
		this.adline2 = adline2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "ServiceRequestAddress [id=" + id + ", SRid=" + SRid + ", adline1=" + adline1 + ", adline2=" + adline2
				+ ", city=" + city + ", state=" + state + ", post=" + post + ", mobile=" + mobile + ", email=" + email
				+ "]";
	}
	
	
	
}
