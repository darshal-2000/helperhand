package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServicedetailForSP;

@Repository
public class ServicedetailForSPDAOImpl implements ServicedetailForSPDAO {
	@Autowired
    private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<ServicedetailForSP> getServicesForSP(String post) {
		 Session session = sessionFactory.getCurrentSession();
	        String hql = "FROM ServicedetailForSP u WHERE u.post = :post AND u.request.jobStatus=0 AND u.request.SP_Id =0";
	        Query query = session.createQuery(hql);
	        query.setParameter("post", post);
	        if(query.getResultList().size()==0) {
	        	return null;
	        }
	        return query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ServicedetailForSP> getUpComingServicesForSP(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM ServicedetailForSP u WHERE u.request.jobStatus=0 AND u.request.SP_Id =:id";
        Query query = session.createQuery(hql);
        query.setParameter("id",id);
        if(query.getResultList().size()==0) {
        	return null;
        }
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServicedetailForSP> getServicesHistoryForSP(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM ServicedetailForSP u WHERE u.request.jobStatus=1 AND u.request.SP_Id =:id";
        Query query = session.createQuery(hql);
        query.setParameter("id",id);
        if(query.getResultList().size()==0) {
        	return null;
        }
		return query.getResultList();
	}

	

}
