package project.helperland.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.BlockCustomer;


@Repository
public class BlockCustomerDAOImpl implements BlockCustomerDAO{
	@Autowired
    private SessionFactory sessionFactory;

	@Override
	public void saveBlock(BlockCustomer theUser) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(theUser);
	}

	@Override
	public int isBlock(int userId, int TargetId) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM BlockCustomer u WHERE u.userId = :userId AND u.TargetUserId = :TargetId AND IsBlock = 1";
        Query query = session.createQuery(hql);
        query.setParameter("userId",userId);
        query.setParameter("TargetId", TargetId);
        if(query.getResultList().size()>0) {
        	return 1;
        }
		return 0;
	}

	@Override
	public BlockCustomer CheckData(int userId, int TargetId) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "FROM BlockCustomer u WHERE u.userId = :userId AND u.TargetUserId = :TargetId";
        Query query = session.createQuery(hql);
        query.setParameter("userId",userId);
        query.setParameter("TargetId", TargetId);
        if(query.getResultList().size()>0) {
        	return (BlockCustomer) query.getResultList().get(0);
        }
        return null;
	}
	
	
}
