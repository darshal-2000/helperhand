package project.helperland.service;

import project.helperland.entity.ContactUs;

public interface ContactUsService {
	public void saveContactUs(ContactUs contact);
}
