package project.helperland.service;

import java.util.List;

import project.helperland.entity.CustomerDashboard;

public interface CustomerDashboardService {
	public List<CustomerDashboard> getDetail(String id);
	public CustomerDashboard getservicedetail(int id);
	public int update(int id,String on,String at);
	public int checkSPdateANDtime(int id,String on,String at);
	public void CancelService(int id,String reason);
	public List<CustomerDashboard> getServiceHistory(String id);
}
