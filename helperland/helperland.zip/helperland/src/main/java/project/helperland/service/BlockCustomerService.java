package project.helperland.service;

import project.helperland.entity.BlockCustomer;

public interface BlockCustomerService {
	
	public void saveBlock(BlockCustomer theUser);
	
	public int isBlock(int userId,int TargetId);
	
	public BlockCustomer CheckData(int userId,int TargetId);
}
