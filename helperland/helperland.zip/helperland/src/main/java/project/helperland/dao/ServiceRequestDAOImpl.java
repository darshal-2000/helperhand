package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServiceRequest;



@Repository
public class ServiceRequestDAOImpl implements ServiceRequestDAO {
	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
    public void saveService(ServiceRequest service) {
        Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(service);
    }

	@Override
	public ServiceRequest getService(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		return currentSession.get(ServiceRequest.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getUsersOfSP(int id) {
		Session session = sessionFactory.getCurrentSession();
        String hql = "SELECT DISTINCT u.id FROM ServiceRequest u WHERE u.SP_Id = :id";
        Query query = session.createQuery(hql);
        query.setParameter("id", id);
        return query.getResultList();
	}
	
}
