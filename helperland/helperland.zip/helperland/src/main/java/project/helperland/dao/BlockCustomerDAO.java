package project.helperland.dao;

import project.helperland.entity.BlockCustomer;

public interface BlockCustomerDAO {
	public void saveBlock(BlockCustomer theUser);
	
	public int isBlock(int userId,int TargetId);
	
	public BlockCustomer CheckData(int userId,int TargetId);
}
