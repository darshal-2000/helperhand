package project.helperland.service;

import java.util.List;

import project.helperland.entity.SP_Rating;

public interface SP_RatingService {
	public List<SP_Rating> getRatings(int id);
}
