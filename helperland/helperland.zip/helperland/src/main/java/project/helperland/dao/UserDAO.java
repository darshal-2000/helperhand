package project.helperland.dao;

import java.util.List;

import project.helperland.entity.User;

public interface UserDAO {
	public List < User > getUser();

    public void saveUser(User theUser);

    public User getUser(int theId);

    public void deleteUser(int theId);
    
    public List <User> login(String email,String pass);
    
    public int emailvalid(String email);
    
    public void updatepass(String email,String pass);
    
}
