package project.helperland.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.SP_RatingDAO;
import project.helperland.entity.SP_Rating;

@Service
public class SP_RatingServiceImpl implements SP_RatingService{
	@Autowired
	SP_RatingDAO rating;

	@Override
	@Transactional
	public List<SP_Rating> getRatings(int id) {
		return rating.getRatings(id);
	}
}
