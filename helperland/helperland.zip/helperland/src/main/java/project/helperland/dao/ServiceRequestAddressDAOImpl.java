package project.helperland.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import project.helperland.entity.ServiceRequestAddress;

@Repository
public class ServiceRequestAddressDAOImpl implements ServiceRequestAddressDAO {
	@Autowired
    private SessionFactory sessionFactory;
	
	@Override
	public void saveSercvice(ServiceRequestAddress thead) {
		Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(thead);
	}
	
	@Override
	public ServiceRequestAddress getbySRid(int id) {
		 Session session = sessionFactory.getCurrentSession();
	        String hql = "FROM ServiceRequestAddress u WHERE u.SRid = :id";
	        Query query = session.createQuery(hql);
	        query.setParameter("id", id);
	        return (ServiceRequestAddress) query.getResultList().get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> getByPostCode(String post) {
			Session session = sessionFactory.getCurrentSession();
	        String hql = "Select u.SRid FROM ServiceRequestAddress u WHERE u.post = :id";
	        Query query = session.createQuery(hql);
	        query.setParameter("id", post);
	        if(query.getResultList().size()>0) {
	        	return query.getResultList();
	        }
		return null;
	}
}
