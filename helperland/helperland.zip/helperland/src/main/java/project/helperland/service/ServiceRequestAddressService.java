package project.helperland.service;

import project.helperland.entity.ServiceRequestAddress;

public interface ServiceRequestAddressService {
	public void saveSercvice(ServiceRequestAddress thead);
	public ServiceRequestAddress getbySRid(int id);
}
