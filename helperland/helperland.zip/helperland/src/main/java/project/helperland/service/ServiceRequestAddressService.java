package project.helperland.service;

import java.util.List;

import project.helperland.entity.ServiceRequestAddress;

public interface ServiceRequestAddressService {
	public void saveSercvice(ServiceRequestAddress thead);
	public ServiceRequestAddress getbySRid(int id);
	public List<Integer> getByPostCode(String post); 
}
