package project.helperland.entity;

public class Views {
	 public static class Public {}
}
