package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import project.helperland.dao.ServiceRequestAddressDAO;
import project.helperland.entity.ServiceRequestAddress;

@Service
public class ServiceRequestAddressServiceImpl implements ServiceRequestAddressService {
	
	@Autowired
    private ServiceRequestAddressDAO ad;
	
	@Override
	@Transactional
	public void saveSercvice(ServiceRequestAddress thead) {
		ad.saveSercvice(thead);
	}
	
	@Override
	@Transactional
	public ServiceRequestAddress getbySRid(int id) {
		return ad.getbySRid(id);
	}
}
