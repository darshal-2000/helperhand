package project.helperland.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="rating")
public class Rating {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RatingId")
	private int id;
	
	@Column(name="ServiceRequestId")
	private int SR_id;
	
	@Column(name="RatingFrom")
	private int from;
	
	@Column(name="RatingTo")
	private int to;
	
	@Column(name="Rating")
	private float rating;
	
	@Column(name="comment")
	private String comment;
	
	@Column(name="RatingDate")
	private String Date;
	
	@Column(name="OnTimeArrival")
	private float ontime;
	
	@Column(name="Friendly")
	private float friendly;
	
	@Column(name="QualityOfService")
	private float QoS;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getSR_id() {
		return SR_id;
	}

	public void setSR_id(int sR_id) {
		SR_id = sR_id;
	}

	public int getFrom() {
		return from;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	public int getTo() {
		return to;
	}

	public void setTo(int to) {
		this.to = to;
	}

	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public float getOntime() {
		return ontime;
	}

	public void setOntime(float ontime) {
		this.ontime = ontime;
	}

	public float getFriendly() {
		return friendly;
	}

	public void setFriendly(float friendly) {
		this.friendly = friendly;
	}

	public float getQoS() {
		return QoS;
	}

	public void setQoS(float qoS) {
		QoS = qoS;
	}

	@Override
	public String toString() {
		return "Rating [id=" + id + ", SR_id=" + SR_id + ", from=" + from + ", to=" + to + ", rating=" + rating
				+ ", comment=" + comment + ", Date=" + Date + ", ontime=" + ontime + ", friendly=" + friendly + ", QoS="
				+ QoS + "]";
	}

	
}
