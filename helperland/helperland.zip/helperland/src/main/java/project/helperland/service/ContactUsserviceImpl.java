package project.helperland.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import project.helperland.dao.ContactUsDAO;
import project.helperland.entity.ContactUs;

@Service
public class ContactUsserviceImpl implements ContactUsService {
	@Autowired
	private ContactUsDAO contactusDAO;
	
	@Override
	@Transactional
	public void saveContactUs(ContactUs contact) {
		contactusDAO.saveContactUs(contact);
	}	
}
